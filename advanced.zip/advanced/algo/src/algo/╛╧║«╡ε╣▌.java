package algo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.LinkedList;
import java.util.Queue;
import java.util.StringTokenizer;

public class �Ϻ���� {
	// �� �� �� ��
	static int[] dy = {-1, 1, 0, 0};
	static int[] dx = {0, 0, -1, 1};
	static int N, M;
	static boolean[][] vtd;
	
	static int[][] map;
	static int answer;
	static Point goal, start;

	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st;
		StringBuilder sb = new StringBuilder();
		int T = Integer.parseInt(br.readLine());
		
		for(int t = 1; t <= T; t++) {
			st = new StringTokenizer(br.readLine());
			N = Integer.parseInt(st.nextToken());
			M = Integer.parseInt(st.nextToken());
			answer = Integer.MAX_VALUE;
			map = new int[N][M];
			for(int i = 0; i < N; i++) {
				st = new StringTokenizer(br.readLine());
				for(int j = 0; j < M; j++) {
					map[i][j] = Integer.parseInt(st.nextToken());
					if(map[i][j] == 2) start = new Point(i, j);
					else if(map[i][j] == 3) goal = new Point(i, j);
				}
			}
			
			for(int i = 1; i <= N; i++) {
				vtd = new boolean[N][M];
				BFS(i);
				if(answer != Integer.MAX_VALUE) break;
			}
			sb.append("#").append(t).append(" ").append(answer).append("\n");
			
		}
		
		System.out.print(sb);
	}
	static void BFS(int level) {
		Queue<Point> q = new LinkedList<>();
		q.add(start);
		
		while(!q.isEmpty()) {
			Point p = q.poll();
			if(goal.y == p.y && goal.x == p.x) {
				answer = level;
				return;
			}
			
			if(vtd[p.y][p.x]) continue;
			vtd[p.y][p.x] = true;
			
			for(int i = 0; i < 4; i++) {
				for(int l = 1; l <= level; l++) {
					int ny = p.y + l*dy[i];
					int nx = p.x + l*dx[i];
					if(ny < 0 || ny >= N || nx < 0 || nx >= M || vtd[ny][nx] || map[ny][nx] == 0) continue;
					q.add(new Point(ny, nx));
				}
			}
		}
	}
	
	static class Point{
		int y, x;
		public Point(int y, int x) {
			this.y = y;
			this.x = x;
		}
	}

}
