package algo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class ����_�ڵ���_������ {
	static int[] src = new int[31];
	static ArrayList<Home> homeList;
	static boolean[][] vtd;
	static int answer;
	static int N;
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st;
		StringBuilder sb = new StringBuilder();
		for(int i = -15; i <= 15; i++) src[i+15] = i;
		int T = Integer.parseInt(br.readLine());
		
		for(int t = 1; t <= T; t++) {
			homeList = new ArrayList<>();
			vtd = new boolean[31][31];
			answer = Integer.MAX_VALUE;
			N = Integer.parseInt(br.readLine());
			
			for(int i = 0; i < N; i++) {
				st = new StringTokenizer(br.readLine());
				
				int x = Integer.parseInt(st.nextToken());
				int y = Integer.parseInt(st.nextToken());
				int d = Integer.parseInt(st.nextToken());
				
				homeList.add(new Home(y, x, d));
				vtd[y+15][x+15] = true;
			}
			
			DFS(new Point(15,-15));
			if(answer == Integer.MAX_VALUE) comb(0,0,0,new Point[2]);	
			if(answer == Integer.MAX_VALUE) answer = -1;
			sb.append("#").append(t).append(" ").append(answer).append("\n");
			
		}
		System.out.print(sb);
	}
	
	static void DFS(Point chargePlace) {
		if(chargePlace.x == 16) { // �� �����ʿ� ���� ��� �ٽ� �� ���ʺ���
			chargePlace.y -= 1;
			chargePlace.x = -15;
		}
		if(chargePlace.y == -16 && chargePlace.x == -15 || vtd[chargePlace.y+15][chargePlace.x+15]) return;
		vtd[chargePlace.y+15][chargePlace.x+15] = true;
		
		int sum = 0;
		boolean flag = false;
		for(Home home : homeList) {
			int homeToCharge = checkDistance(home, chargePlace);
			if(homeToCharge > home.d) { // ���� ���� ������ �ƴѰ��
				flag = true;
				break;
			}
			sum += homeToCharge;
		}
		
		if(!flag) answer = Math.min(answer, sum);
		DFS(new Point(chargePlace.y, chargePlace.x + 1));
	}
	
	static void lastChance(Point chargePlace1, Point chargePlace2) {
		int sum = 0;
		for(Home home : homeList) {
			if(home.y == chargePlace1.y && home.x == chargePlace1.x) return;
			if(home.y == chargePlace2.y && home.x == chargePlace2.x) return;
			
			int homeToCharge1 = checkDistance(home, chargePlace1);
			int homeToCharge2 = checkDistance(home, chargePlace2);
			
			int min = Math.min(homeToCharge1, homeToCharge2);
			
			if(min > home.d) return;
			sum += min;
		}
		
		answer = Math.min(answer, sum);
	}
	
	static void comb(int L, int yStart, int xStart, Point[] ans){
		if(L == 2) {
			lastChance(ans[0], ans[1]);
			return;
		}
		
		if(yStart > 30 && xStart > 30) return;
		
		if(xStart == 31) {
			xStart = 0;
			yStart += 1;
		}
		
		for(int i = yStart; i < src.length; i++) {
			for(int j = xStart; j < src.length; j++) {
				ans[L] = new Point(src[i], src[j]);	
				comb(L+1, i, j+1, ans);
			}
		}
	}
	
	static int checkDistance(Home h1, Point p1) {
		return Math.abs(h1.x - p1.x) + Math.abs(h1.y - p1.y);
	}
	
	static class Point{
		int y, x;
		public Point(int y, int x) {
			this.y = y;
			this.x = x;
		}
	}
	static class Home extends Point{
		int d;

		public Home(int y, int x, int d) {
			super(y, x);
			this.d = d;
		}
	}

}
