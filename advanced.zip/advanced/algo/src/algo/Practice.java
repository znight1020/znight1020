package algo;

public class Practice {

	public static void main(String[] args) {
		System.out.println("Hello");

	}
}
